/** Automatically generated file. DO NOT MODIFY */
package com.studiosudo.pollisticssdo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}