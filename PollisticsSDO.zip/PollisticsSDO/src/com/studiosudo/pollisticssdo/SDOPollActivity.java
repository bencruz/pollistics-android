/* SDO Poll Activity
 * Superclass to contain shared data such as app preferences
 * @param none
*/
package com.studiosudo.pollisticssdo;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;

public class SDOPollActivity extends Activity 
{
	public static final String APP_PREFERENCES = "AppPrefs";
	public static final String APPTAG = "SDO"; 
}
